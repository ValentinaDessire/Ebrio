import './App.css';
import EbrioSimulacion from './components/simuladorBorracho';

function App() {
  return (
    <div className="App">
      <EbrioSimulacion/>
    </div>
  );
}

export default App;
